﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO;

using BE;
using DS;

namespace DAL
{
    public class DALimp : IDAL
    {
        public DALimp()
        {

        }

        public void addEvent(Action<object, EventArgs> func)
        {
            DS_Flowers DSF = new DS_Flowers();
            DSF.addEvent(func);
        }
        
        public CurrencyObject RefreshCurrency(string ACCESS_KEY)
        {
            DS_Flowers DSF = new DS_Flowers();
            return DSF.RefreshCurrency(ACCESS_KEY);
        }
    }
}
