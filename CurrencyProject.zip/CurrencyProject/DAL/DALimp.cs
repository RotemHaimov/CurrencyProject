﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO;

using BE;
using DS;

namespace DAL
{
    public class DALimp : IDAL
    {
        public DALimp()
        {

        }

        public List<CurrencyObject> Currencies
        {
            get
            {
                DS_Currencies DSF = new DS_Currencies();
                return DSF.Currencies;
            }
        }

        public void addEvent(Action<object, EventArgs> func)
        {
            DS_Currencies DSF = new DS_Currencies();
            DSF.addEvent(func);
        }
        
        async public Task<CurrencyObject> RefreshCurrency(string ACCESS_KEY)
        {
            DS_Currencies DSF = new DS_Currencies();
            return await DSF.RefreshCurrency(ACCESS_KEY);
        }
    }
}
