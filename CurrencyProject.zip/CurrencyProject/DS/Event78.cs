﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DS
{
    public class Event78
    {
        public static event EventHandler<EventArgs> flowerAdded;
        public EventHandler<EventArgs> getHandler()
        {
            return flowerAdded;
        }
    }
}
