﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BE;
using System.Xml.Linq;
using System.IO;
using Newtonsoft.Json;

namespace DS
{
    public class DS_Flowers : Event78
    {
        public string Flowers_fname, Config_fname;
        public XElement FlowersRoot, ConfigRoot;
        public API_Layer apl;

        long LastTimeStamp = 0;
        //public int FlowerCount = 0;

        public DS_Flowers()
        {
            //Flowers_fname = @"..\..\xml\Flowers.xml";
            Config_fname = @"..\..\xml\Config.xml";
            //CreateOrSave(ref FlowersRoot, Flowers_fname, "Flowers");
            CreateOrSave(ref ConfigRoot, Config_fname, "Config");

            InitConfig();
        }

        private void InitConfig()
        {
            //FlowerCount = Convert.ToInt32(ConfigRoot.Element("FlowerCount").Value);
            LastTimeStamp = Convert.ToInt32(ConfigRoot.Element("LastTimeStamp").Value);
        }

        private void CreateOrSave(ref XElement root, string fname, string labelName)
        {
            if (!File.Exists(fname))
            {
                root = new XElement(labelName);
                if (labelName == "Config")
                {
                    //root.Add(new XElement("FlowerCount", 0));
                    root.Add(new XElement("LastTimeStamp", 0));
                }
                root.Save(fname);
            }
            else root = XElement.Load(fname);
        }

        public void addEvent(Action<object, EventArgs> func)
        {
            flowerAdded += new EventHandler<EventArgs>(func);
        }
        public List<Flower> getFlowers()
        {
            return null;
        }
        public CurrencyObject RefreshCurrency(string ACCESS_KEY)
        {
            apl = new API_Layer(ACCESS_KEY);
            string content = apl.SendRequest();
            saveToFile(content);

            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);

            onCurrencyRefreshed(new EventArgs());

            return Obj;
        }
        private void saveToFile(string content)
        {
            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);
            LastTimeStamp = Obj.timestamp;
            UpdateConfig(LastTimeStamp, "LastTimeStamp");
            File.WriteAllText(@"..\..\..\json\" + LastTimeStamp.ToString() + ".json", content);
        }
        private void onCurrencyRefreshed(EventArgs e)
        {
            getHandler()?.Invoke(this, e);
        }

        private void UpdateConfig(long count, string labelName)
        {
            ConfigRoot.Element(labelName).Value = count.ToString();
            ConfigRoot.Save(Config_fname);
        }
    }
}
