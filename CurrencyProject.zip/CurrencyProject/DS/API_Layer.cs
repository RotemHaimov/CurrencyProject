﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class API_Layer
    {
        // essential URL structure is built using constants
        //private string ACCESS_KEY = ConfigurationSettings.AppSettings["ACCESS_KEY"];
        private const string BASE_URL = "http://apilayer.net/api/";
        private const string ENDPOINT_LIVE = "live";
        private const string ENDPOINT_HISTORICAL = "historical";
        private const string access_key = "?access_key=";
        private const string date = "&date=";
        private const string format = "&format=";
        private const string FORMAT = "1";

        private string liveRequest;
        private string historicalRequest;

        public API_Layer(string ACCESS_KEY)
        {
            liveRequest = BASE_URL + ENDPOINT_LIVE + access_key + ACCESS_KEY + format + FORMAT;
            historicalRequest = BASE_URL + ENDPOINT_HISTORICAL + access_key + ACCESS_KEY + date;
        }

        async public Task<string> SendRequest(string endpoint = "live", string date = "2010-12-30")
        {
            string toSend;
            if (endpoint == "live") toSend = liveRequest;
            else toSend = historicalRequest + date + format + FORMAT;
            // Create a request for the URL.
            WebRequest request = WebRequest.Create(toSend);
            // If required by the server, set the credentials.  
            request.Credentials = CredentialCache.DefaultCredentials;
            // Get the response.  
            WebResponse response = request.GetResponse();
            // Display the status.  
            Console.WriteLine(((HttpWebResponse)response).StatusDescription);
            // Get the stream containing content returned by the server.  
            Stream dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.  
            StreamReader reader = new StreamReader(dataStream);
            // Read the content.  
            string responseFromServer = reader.ReadToEnd();
            // Display the content.  
            //Console.WriteLine(responseFromServer);
            // Clean up the streams and the response.  
            reader.Close();
            response.Close();
            return responseFromServer;
        }
        
        /*public void RefreshCurrency() //not needed
        {
            string content = SendRequest();
            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);
            long fname = Obj.timestamp;
            File.WriteAllText(@"..\..\..\json\" + fname.ToString() + ".json", content);

            //DateTime dt = UnixTimeStampToDateTime(Obj.timestamp);
            //Console.WriteLine(dt.ToString());

            //double timestamp = DateTimeToUnixTimestamp(dt);
            //Console.WriteLine(timestamp);

            //Console.WriteLine(content.ToString());

            //content = LRD.SendRequest("historical", "2015-11-30");
            //Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);
        }*/
    }
}
