﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BE;
using System.Xml.Linq;
using System.IO;
using Newtonsoft.Json;

namespace DS
{
    public class DS_Currencies : Event78
    {
        public string Flowers_fname, Config_fname;
        public XElement FlowersRoot, ConfigRoot;
        public API_Layer apl;

        long LastTimeStamp = 0;

        public DS_Currencies()
        {
            Config_fname = @"..\..\xml\Config.xml";
            CreateOrSave(ref ConfigRoot, Config_fname, "Config");

            InitConfig();
        }

        private void InitConfig()
        {
            LastTimeStamp = Convert.ToInt32(ConfigRoot.Element("LastTimeStamp").Value);
        }

        private void CreateOrSave(ref XElement root, string fname, string labelName)
        {
            if (!File.Exists(fname))
            {
                root = new XElement(labelName);
                if (labelName == "Config")
                {
                    root.Add(new XElement("LastTimeStamp", 0));
                }
                root.Save(fname);
            }
            else root = XElement.Load(fname);
        }

        public void addEvent(Action<object, EventArgs> func)
        {
            flowerAdded += new EventHandler<EventArgs>(func);
        }
        public List<Flower> getFlowers()
        {
            return null;
        }
        async public Task<CurrencyObject> RefreshCurrency(string ACCESS_KEY)
        {
            apl = new API_Layer(ACCESS_KEY);
            string content = await apl.SendRequest();
            saveToFile(content);

            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);

            onCurrencyRefreshed(new EventArgs());

            return Obj;
        }
        private void saveToFile(string content)
        {
            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);
            LastTimeStamp = Obj.timestamp;
            UpdateConfig(LastTimeStamp, "LastTimeStamp");
            File.WriteAllText(@"..\..\..\json\" + LastTimeStamp.ToString() + ".json", content);
        }
        private void onCurrencyRefreshed(EventArgs e)
        {
            getHandler()?.Invoke(this, e);
        }

        private void UpdateConfig(long count, string labelName)
        {
            ConfigRoot.Element(labelName).Value = count.ToString();
            ConfigRoot.Save(Config_fname);
        }

        public List<CurrencyObject> Currencies
        {
            get
            {
                List<CurrencyObject> currs = new List<CurrencyObject>();
                ReadCurrenciesFromJson(currs);
                return currs;
            }
        }

        private void ReadCurrenciesFromJson(List<CurrencyObject> currs)
        {
            string[] filePaths = Directory.GetFiles(@"..\..\..\json\");
            foreach(string path in filePaths)
            {
                currs.Add(CurrFileToObj(path));
            }
        }

        private CurrencyObject CurrFileToObj(string path)
        {
            string content = File.ReadAllText(path);
            var Obj = JsonConvert.DeserializeObject<CurrencyObject>(content);
            return Obj;
        }
    }
}
