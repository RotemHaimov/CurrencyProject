﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;
using System.Reflection;

namespace BE
{
    public static class BE_Extensions
    {
        public static string ObjectToXML(object o)
        {
            StringWriter sw = new StringWriter();
            XmlTextWriter tw = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(o.GetType());
                tw = new XmlTextWriter(sw);
                serializer.Serialize(tw, o);
            }
            catch (Exception ex)
            {
                //Handle Exception Code
            }
            finally
            {
                sw.Close();
                if (tw != null)
                {
                    tw.Close();
                }
            }
            return sw.ToString();
        }
        public static Object XMLtoObject(string xml, Type objectType)
        {
            StringReader strReader = null;
            XmlSerializer serializer = null;
            XmlTextReader xmlReader = null;
            Object obj = null;
            try
            {
                strReader = new StringReader(xml);
                serializer = new XmlSerializer(objectType);
                xmlReader = new XmlTextReader(strReader);
                obj = serializer.Deserialize(xmlReader);
            }
            catch (Exception exp)
            {
                //Handle Exception Code
            }
            finally
            {
                if (xmlReader != null)
                {
                    xmlReader.Close();
                }
                if (strReader != null)
                {
                    strReader.Close();
                }
            }
            return obj;
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dt = dt.AddSeconds(unixTimeStamp).ToLocalTime();
            return dt;
        }

        public static double DateTimeToUnixTimestamp(DateTime dateTime)
        {
            return (TimeZoneInfo.ConvertTimeToUtc(dateTime) -
                   new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc)).TotalSeconds;
        }

        public static float Translate(CurrencyObject CurrentCurrency, string source, string dest)
        {
            PropertyInfo[] properties = CurrentCurrency.quotes.GetType().GetProperties();
            PropertyInfo src, dst;
            float srcCur, dstCur;
            try
            {
                src = properties.FirstOrDefault(p => p.Name.Substring(3) == source);
                dst = properties.FirstOrDefault(p => p.Name.Substring(3) == dest);

                srcCur = (float)src.GetValue(CurrentCurrency.quotes);
                dstCur = (float)dst.GetValue(CurrentCurrency.quotes);

                return dstCur / srcCur;
            }
            catch { }
            return -1;
        }

        public static string OneCurrency(CurrencyObject co, string src)
        {
            return "";
        }

        public static string ToString(CurrencyObject co)
        {
            string ans = "";
            PropertyInfo[] properties = co.quotes.GetType().GetProperties();
            foreach(PropertyInfo p in properties)
            {
                ans += p.Name + ": " + p.GetValue(co.quotes) + "\n";
            }
            return ans;
        }
    }
}
