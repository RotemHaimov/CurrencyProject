﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using static System.Net.Mime.MediaTypeNames;

namespace BE
{
    public class Flower
    {
        public string name { get; set; }
        public ConsoleColor color { get; set; }

        public Flower()
        {

        }
        public Flower(string name, ConsoleColor color)
        {
            this.name = name;
            this.color = color;
        }
        public override string ToString()
        {
            return "Name: " + name + ", Color: " + color.ToString();
        }
    }
}
