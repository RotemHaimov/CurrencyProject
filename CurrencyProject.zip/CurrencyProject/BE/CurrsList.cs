﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class CurrsList
    {
        public List<string> currsList { get; set; }
        public CurrsList()
        {
            currsList = new List<string>();
            PropertyInfo[] properties = typeof(Quotes).GetProperties();
            foreach (PropertyInfo prop in properties)
            {
                currsList.Add(prop.Name.Substring(3));
            }
        }
    }
}
