﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class CurrencyObject
    {
        /*
         * "success":true,
         * "terms":"https:\/\/currencylayer.com\/terms",
         * "privacy":"https:\/\/currencylayer.com\/privacy",
         * "timestamp":1513167970,
         * "source":"USD",
         */

        public bool success { get; set; }
        public string terms { get; set; }
        public string privacy { get; set; }
        public long timestamp { get; set; }
        public string source { get; set; }

        public Quotes quotes = new Quotes();

        public CurrencyObject()
        { }
    }
}
