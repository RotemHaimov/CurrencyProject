﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BE;

namespace BL
{
    public interface IBL
    {
        void addEvent(Action<object, EventArgs> func);

        Task<CurrencyObject> RefreshCurrency(string ACCESS_KEY);
        List<CurrencyObject> Currencies { get; }
    }
}
