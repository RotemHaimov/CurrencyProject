﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DAL;
using BE;

namespace BL
{
    public class BLimp : IBL
    {
        public void addEvent(Action<object, EventArgs> func)
        {
            IDAL DAL = new DALimp();
            DAL.addEvent(func);
        }

        public CurrencyObject RefreshCurrency(string ACCESS_KEY)
        {
            IDAL DAL = new DALimp();
            return DAL.RefreshCurrency(ACCESS_KEY);
        }
    }
}
