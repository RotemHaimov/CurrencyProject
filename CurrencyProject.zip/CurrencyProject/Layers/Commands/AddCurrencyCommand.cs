﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using Layers.ViewModels;

namespace Layers.Commands
{
    public class AddCurrencyCommand : ICommand
    {
        private ICurrenciesViewModel CurrentVM;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public AddCurrencyCommand(ICurrenciesViewModel viewModel)
        {
            CurrentVM = viewModel;
        }

        public event Action<string> CurrencyAdded;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (CurrencyAdded != null)
                CurrencyAdded("test");
        }
    }
}
