﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using BE;

namespace Layers.Converters
{
    class TranslatorMultiValueConverter : IMultiValueConverter
    {
        /// <summary>
        /// value[0]=src
        /// value[1]=dst
        /// value[2]=amount
        /// value[3]=Currencies
        /// </summary>
        /// <param name="values"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            string ans = "";
            /*foreach(var x in values)
            {
                if (x == null) return "null";
                ans += x.ToString();
            }*/
            string src = values[0] as string;
            string dst = values[1] as string;
            float amount = System.Convert.ToSingle(values[2]);
            CurrencyObject[] currencies = values[3] as CurrencyObject[];
            if (currencies == null) return "";
            CurrencyObject current = currencies[currencies.Length - 1];
            ans = (BE_Extensions.Translate(current, src, dst) * amount).ToString();
            return ans;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
