﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Configuration;
using System.Reflection;

using BE;
using BL;
using System.Threading;
using Layers.ViewModels;
using System.Windows.Controls.DataVisualization.Charting;

namespace Layers
{
    /// <summary>
    /// Interaction logic for MainWindow2.xaml
    /// </summary>
    public partial class MainWindow2 : Window
    {
        public CurrenciesViewModel CurrentVM { get; set; }
        public MainWindow2()
        {
            InitializeComponent();
            InitializeListsItemsSource();

            IBL BL = new BLimp();
            BL.addEvent(CurrencyRefreshed);

            CurrentVM = new CurrenciesViewModel();
            this.DataContext = CurrentVM;
        }

        private void InitializeListsItemsSource()
        {
            CurrsList cl = new CurrsList();
            acDstHistory.CustomSource = acSrcHistory.CustomSource = acDstTranslate.CustomSource = acSrcTranslate.CustomSource = /*acSrc.CustomSource = */cl.currsList;
            acDstTranslate.SelectedItem = /*acSrc.SelectedItem =*/ acSrcHistory.SelectedItem = "ILS";
            acSrcTranslate.SelectedItem = acDstHistory.SelectedItem = "USD";
        }

        public void CurrencyRefreshed(object sender, EventArgs e)
        {
            MessageBox.Show("Currency Refreshed Successfully!");
        }

        private void acSrc_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //string src = (string)acSrc.SelectedItem;
            //string ans = BE_Extensions.OneCurrency(CurrentVM.Currencies[CurrentVM.Currencies.Count - 1], src);
            string ans = BE_Extensions.ToString(CurrentVM.Currencies[CurrentVM.Currencies.Count - 1]);
            currencyLabel.Content = ans;
        }

        private void translateBtn_Click(object sender, RoutedEventArgs e)
        {
            float price = Convert.ToSingle(curTB.Text);
            CurrencyObject current = CurrentVM.Currencies[CurrentVM.Currencies.Count - 1];
            float translated = BE_Extensions.Translate(current, acSrcTranslate.Text, acDstTranslate.Text);

            if (translated == -1) //illegal source OR dest...
                return;

            resultTB.Content = (price * translated).ToString();
        }

        private void updateChart()
        {
            string src = (string)acSrcHistory.SelectedItem;
            string dst = (string)acDstHistory.SelectedItem;
            try
            {
                CurrentVM.LoadColumnChartData(src, dst);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            srcHistoryLabel.Content += "";
        }

        private void acSrcHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            updateChart();
        }

        private void acDstHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            updateChart();
        }

        private void ScrollViewer_Loaded(object sender, RoutedEventArgs e)
        {
            string ans = BE_Extensions.ToString(CurrentVM.Currencies[CurrentVM.Currencies.Count - 1]);
            currencyLabel.Content = ans;
        }
    }
}
