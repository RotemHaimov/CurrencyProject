﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using Layers.Models;
using Layers.Commands;

namespace Layers.ViewModels
{
    public class CurrenciesViewModel : INotifyPropertyChanged, ICurrenciesViewModel
    {
        public ObservableCollection<CurrencyObject> Currencies { get; set; }
        public KeyValuePair<string, float>[] SrcDstCurrencyChart { get; set; }
        public KeyValuePair<string, float>[] SrcDstCurrencyChartProperty
        {
            get { return SrcDstCurrencyChart; }
            set
            {
                SrcDstCurrencyChart = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("SrcDstCurrencyChartProperty"));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private CurrencyModel CurrencyModel { get; set; }
        public AddCurrencyCommand AddCurrency { get; set; }
        
        public CurrenciesViewModel()
        {
            this.CurrencyModel = new CurrencyModel();
            Currencies = new ObservableCollection<CurrencyObject>(CurrencyModel.Currencies);
            Currencies.CollectionChanged += Currencies_CollectionChanged;
            AddCurrency = new AddCurrencyCommand(this);
            AddCurrency.CurrencyAdded += AddCurrency_CurrencyAdded;
            LoadColumnChartData();
        }

        async private void AddCurrency_CurrencyAdded(string obj)
        {
            CurrencyObject co = await CurrencyModel.AddCurrency();
            if (Currencies[Currencies.Count - 1].timestamp == co.timestamp) return;
            Currencies.Add(co);
        }

        private void Currencies_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void LoadColumnChartData(string src = "ILS", string dst = "EUR")
        {
            SrcDstCurrencyChartProperty = CurrencyModel.LoadColumnChartData(src, dst);
        }
    }
}
