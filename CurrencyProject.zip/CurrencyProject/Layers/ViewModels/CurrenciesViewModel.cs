﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using Layers.Models;
using Layers.Commands;

namespace Layers.ViewModels
{
    public class CurrenciesViewModel : INotifyPropertyChanged, ICurrenciesViewModel
    {
        public ObservableCollection<CurrencyObject> Currencies { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        private CurrencyModel CurrencyModel { get; set; }
        public AddCurrencyCommand AddCurrency { get; set; }

        public CurrenciesViewModel()
        {
            this.CurrencyModel = new CurrencyModel();
            Currencies = new ObservableCollection<CurrencyObject>(CurrencyModel.Currencies);
            Currencies.CollectionChanged += Currencies_CollectionChanged;
            AddCurrency = new AddCurrencyCommand(this);
            AddCurrency.CurrencyAdded += AddCurrency_CurrencyAdded;
        }

        private void AddCurrency_CurrencyAdded(string obj)
        {
            Currencies.Add(new CurrencyObject()); //add new currency to list
            CurrencyModel.AddCurrency(); //add new currency to FILES!
        }

        private void Currencies_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
