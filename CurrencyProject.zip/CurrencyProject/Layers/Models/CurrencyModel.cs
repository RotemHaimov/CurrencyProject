﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using BE;
using BL;

namespace Layers.Models
{
    class CurrencyModel
    {
        public List<CurrencyObject> Currencies { get; set; }
        CurrencyObject CurrentCurrency;

        public CurrencyModel()
        {
            Currencies = new List<CurrencyObject>();

            initializeTimer();
        }

        private void initializeTimer()
        {
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(3, 0, 0);
            dispatcherTimer.Start();
        }
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            RefreshCurrencyWithThread();
        }

        public void AddCurrency()
        {
            RefreshCurrencyWithThread();
            //if (CurrentCurrency == null) return;
        }

        private void RefreshCurrencyWithThread()
        {
            Thread t = new Thread(RefreshCurrency);
            t.Start();
        }

        private void RefreshCurrency()
        {
            string ACCESS_KEY = ConfigurationSettings.AppSettings["ACCESS_KEY"];
            IBL BL = new BLimp();
            CurrentCurrency = BL.RefreshCurrency(ACCESS_KEY);
        }
    }
}
