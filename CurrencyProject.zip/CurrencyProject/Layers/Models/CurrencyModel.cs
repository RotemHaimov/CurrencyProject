﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using BE;
using BL;

namespace Layers.Models
{
    class CurrencyModel
    {
        public List<CurrencyObject> Currencies { get; set; }
        CurrencyObject CurrentCurrency;

        public CurrencyModel()
        {
            IBL BL = new BLimp();
            Currencies = BL.Currencies;
            CurrentCurrency = Currencies[Currencies.Count - 1];
        }

        async public Task<CurrencyObject> AddCurrency()
        {
            CurrentCurrency = await RefreshCurrency();
            return CurrentCurrency;
        }

        async private Task<CurrencyObject> RefreshCurrency()
        {
            string ACCESS_KEY = ConfigurationSettings.AppSettings["ACCESS_KEY"];
            IBL BL = new BLimp();
            return await BL.RefreshCurrency(ACCESS_KEY);
        }

        public KeyValuePair<string, float>[] LoadColumnChartData()
        {
            string src = "ILS", dst = "EUR";
            KeyValuePair<string, float>[] srcdst = new KeyValuePair<string, float>[Currencies.Count];

            PropertyInfo[] properties = CurrentCurrency.quotes.GetType().GetProperties();
            PropertyInfo sourceProperty, destProperty;

            float srcCur, dstCurTranslated;
            DateTime date;

            sourceProperty = properties.FirstOrDefault(p => p.Name.Substring(3) == src);
            destProperty = properties.FirstOrDefault(p => p.Name.Substring(3) == dst);
            if (sourceProperty == null || destProperty == null) throw new Exception("source or dest not found!");
            
            for (int i = 0; i < srcdst.Length; i++)
            {
                srcCur = (float)sourceProperty.GetValue(Currencies[i].quotes);
                //dstCur = (float)destProperty.GetValue(Currencies[i].quotes);
                dstCurTranslated = BE_Extensions.Translate(Currencies[i], src, dst);
                date = BE_Extensions.UnixTimeStampToDateTime(Currencies[i].timestamp);
                srcdst[i] = new KeyValuePair<string, float>(date.Date.ToShortDateString(), dstCurTranslated);
            }

            return srcdst;
        }
    }
}
